import type { ReactNode } from 'react';
/**
 * Render a body-portaled onboarding stage and keep the application root inert
 * while mounted.
 * @param props.children - the step's page content, centered on the stage.
 * @returns the body-portaled overlay tree.
 */
export declare function OnboardingSurface({ children }: {
    children: ReactNode;
}): import("react").ReactPortal;
//# sourceMappingURL=OnboardingSurface.d.ts.map